ExtremeProof verification bundle

Recompute the verdict from the raw data and check it against the chain:
  python verify.py .                 (offline, uses chain_snapshot in bundle.json)
  python verify.py . --rpc http://127.0.0.1:8545   (also re-reads the live chain)
  python verify.py . --refetch       (also downloads the season again from each publisher
                                      and compares the values; shows what is published today)

history/       data pinned by sha256 in the signed spec, before the season
observations/  what each provider fetched after the season; sha256 in its evidence,
               whose digest the provider reported on chain
verify.py uses only the Python standard library.
